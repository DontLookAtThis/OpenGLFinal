
#include "Dependencies\glew\glew.h"
#include "Dependencies\freeglut\freeglut.h"
#include "Dependencies\soil\SOIL.h"
#include <iostream>

#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/type_ptr.hpp"

static const char* vertex_shader_source[] = {
	"#version 430 core\n"
	"\n"
	"in vec4 vert;\n"
	"\n"
	"uniform mat4 mvp;\n"
	"\n"
	"out float intensity;\n"
	"\n"
	"void main(void)\n"
	"{\n"
	"    intensity = vert.w;\n"//vert.w is the life expectancy of the particle
	"    gl_Position = mvp * vec4(vert.xyz, 1.0);\n"
	"}\n"//;
};

static const char* fragment_shader_source[] = {
	"#version 430 core\n"
	"\n"
	"layout (location = 0) out vec4 color;\n"
	"\n"
	"in float intensity;\n"
	"\n"
	"void main(void)\n"
	"{\n"
	"    color = mix(vec4(0.0f, 0.2f, 1.0f, 1.0f), vec4(0.2f, 0.05f, 0.0f, 1.0f), intensity);\n"
	"}\n"//;
};

static const char* compute_shader_source[] = {
	" #version 430 core \n"
	"layout(std140, binding = 0) uniform attractor_block{ \n"
	"	vec4 attractor[64]; // xyz = position, w = mass \n"
	"}; \n"
	"\n"
	"layout(local_size_x = 128) in;\n"
	"layout(rgba32f, binding = 0) uniform imageBuffer velocity_buffer; \n"
	"layout(rgba32f, binding = 1) uniform imageBuffer position_buffer; \n"
	"\n"
	"uniform float dt = 1.0; \n"
	"\n"
	"void main(void){	\n"
	"vec4 vel = imageLoad(velocity_buffer, int(gl_GlobalInvocationID.x)); \n"
	"vec4 pos = imageLoad(position_buffer, int(gl_GlobalInvocationID.x)); \n"
	"\n"
	"int i; \n"
	"\n"
	"pos.xyz += vel.xyz * dt; \n"
	"pos.w -= 0.0001 * dt; \n"
	"\n"
	"for (i = 0; i < 4; i++){	\n"
	"vec3 dist = (attractor[i].xyz - pos.xyz); \n"
	"\n"
	"vel.xyz += dt * dt * attractor[i].w * normalize(dist) / (dot(dist, dist) + 10.0); \n"
	"}\n"
	"\n"
	"if (pos.w <= 0.0){	\n"
	"		pos.xyz = -pos.xyz * 0.01; \n"
	"		vel.xyz *= 0.01; \n"
	"		pos.w += 1.0f; \n"
	"}\n"
	"\n"
	"imageStore(position_buffer, int(gl_GlobalInvocationID.x), pos); \n"
	"imageStore(velocity_buffer, int(gl_GlobalInvocationID.x), vel); \n"
	"}\n"
	"\n"
};
enum {
	PARTICLE_GROUP_SIZE = 128,
	PARTICLE_GROUP_COUNT = 8000,
	PARTICLE_COUNT = (PARTICLE_GROUP_SIZE * PARTICLE_GROUP_COUNT),
	MAX_ATTRACTORS = 64
};

// Position and velocity buffers
// Union - use same memory region for storing different objects at different times
static union {
	struct {
		GLuint position_buffer;
		GLuint velocity_buffer;
	};
	GLuint buffers[2];
};

// TBOs texture buffer objects
static union {
	struct {
		GLuint position_tbo;
		GLuint velocity_tbo;
	};
	GLuint tbos[2];
};


// Compute program
GLuint  compute_prog;
GLint   dt_location;

// Program, vao and vbo to render a full screen quad
GLuint  render_prog;
GLuint  render_vao;
GLuint  render_vbo;

// Attractor UBO
GLuint  attractor_buffer;

// Mass of the attractors
float attractor_masses[MAX_ATTRACTORS];


static inline float random_float() {
	float res;
	unsigned int tmp;
	static unsigned int seed = 0xFFFF0C59;

	seed *= 16807;
	tmp = seed ^ (seed >> 4) ^ (seed << 15);
	*((unsigned int *)&res) = (tmp >> 9) | 0x3F800000;
	return (res - 1.0f);
}

static glm::vec3 random_vector(float minmag = 0.0f, float maxmag = 1.0f) {
	
	glm::vec3 randomvec(random_float() * 2.0f - 1.0f,
						random_float() * 2.0f - 1.0f,
						random_float() * 2.0f - 1.0f);
	
	
	randomvec = normalize(randomvec);
	randomvec *= (random_float() * (maxmag - minmag) + minmag);
	return randomvec;
}

void init()
{
	//base::Initialize(title);

	int i;

	//** Initialize our compute program
	compute_prog = glCreateProgram();

	GLuint compute_shader = glCreateShader(GL_COMPUTE_SHADER);

	glShaderSource(compute_shader, 1, compute_shader_source, NULL);
	glCompileShader(compute_shader);
	GLint success;
	GLchar infoLog[512];
	glGetShaderiv(compute_shader, GL_COMPILE_STATUS, &success);
	glAttachShader(compute_prog, compute_shader);
	glLinkProgram(compute_prog);

	dt_location = glGetUniformLocation(compute_prog, "dt");

	//
	glGenVertexArrays(1, &render_vao);
	glBindVertexArray(render_vao);

	//position and velocity buffers
	// Generate two buffers, bind them and initialize their data stores
	glGenBuffers(2, buffers);

	//////////////////////////////
	//- Initialise position buffer
	//////////////////////////////
	glBindBuffer(GL_ARRAY_BUFFER, position_buffer);
	glBufferData(GL_ARRAY_BUFFER, PARTICLE_COUNT * sizeof(glm::vec4), NULL, GL_DYNAMIC_COPY);

	// Map the position buffer
	glm::vec4 * positions = (glm::vec4 *)glMapBufferRange(GL_ARRAY_BUFFER,//target
		0,//offset
		PARTICLE_COUNT * sizeof(glm::vec4), //buffer length
		GL_MAP_WRITE_BIT | GL_MAP_INVALIDATE_BUFFER_BIT); //access type

	// Fill it with random vectors
	for (i = 0; i < PARTICLE_COUNT; i++) {
		positions[i] = glm::vec4(random_vector(-10.0f, 10.0f), // positon near the origin
								 random_float()); // life exceptancy
	}

	//unmap buffer
	glUnmapBuffer(GL_ARRAY_BUFFER);

	////////////////////////
	//- set vertex attribute
	////////////////////////
	glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, NULL);
	glEnableVertexAttribArray(0);

	////////////////////////////////////////
	// Initialization of the velocity buffer
	////////////////////////////////////////
	glBindBuffer(GL_ARRAY_BUFFER, velocity_buffer);
	glBufferData(GL_ARRAY_BUFFER, PARTICLE_COUNT * sizeof(glm::vec4), NULL, GL_DYNAMIC_COPY);

	// Map the velocity buffer
	glm::vec4 * velocities = (glm::vec4 *)glMapBufferRange(GL_ARRAY_BUFFER,//target 
		0,//offset
		PARTICLE_COUNT * sizeof(glm::vec4),//buffer length
		GL_MAP_WRITE_BIT | GL_MAP_INVALIDATE_BUFFER_BIT);//access type

	// Filled with random vectors
	for (i = 0; i < PARTICLE_COUNT; i++) {
		velocities[i] = glm::vec4(random_vector(-0.1f, 0.1f), 0.0f);
	}

	//unmap buffer
	glUnmapBuffer(GL_ARRAY_BUFFER);

	/////////////////////////
	//Bind to texture buffers
	/////////////////////////
	glGenTextures(2, tbos);
	for (i = 0; i < 2; i++) {
		glBindTexture(GL_TEXTURE_BUFFER, tbos[i]);
		glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32F, buffers[i]);// bind buffers to textures
	}
	
	///////////////////
	//attractor buffers
	///////////////////

	glGenBuffers(1, &attractor_buffer);
	glBindBuffer(GL_UNIFORM_BUFFER, attractor_buffer);
	glBufferData(GL_UNIFORM_BUFFER, 32 * sizeof(glm::vec4), NULL, GL_STATIC_DRAW);

	// masses for attractors are between 0.5 and 1.0
	// positions are initilized to 0 , but are moved during the render loop
	for (i = 0; i < MAX_ATTRACTORS; i++) {
		attractor_masses[i] = 0.5f + random_float() * 0.5f;
	}

	// Now bind the buffer to the zeroth GL_SHADER_STORAGE_BUFFER
	// binding point
	glBindBufferBase(GL_UNIFORM_BUFFER,// target buffer type
									 0,//index of the binding point
					 attractor_buffer);//name of targret buffer

	
	////////////////////////////
	//** render shader functions
	////////////////////////////

	// Now create a simple program to visualize the result
	render_prog = glCreateProgram();
	GLuint vertex_shader = glCreateShader(GL_VERTEX_SHADER);
	GLuint fragment_shader = glCreateShader(GL_FRAGMENT_SHADER);
	
	glShaderSource(vertex_shader, 1, vertex_shader_source, NULL);
	glShaderSource(fragment_shader, 1, fragment_shader_source, NULL);
	glCompileShader(vertex_shader);
	glCompileShader(fragment_shader);
	glAttachShader(render_prog, vertex_shader);
	glAttachShader(render_prog, fragment_shader);

	glLinkProgram(render_prog);
}

void render(void) {

	static const GLuint start_ticks = ::GetTickCount() - 100000;
	GLuint current_ticks = ::GetTickCount();
	static GLuint last_ticks = current_ticks;
	float time = ((start_ticks - current_ticks) & 0xFFFFF) / float(0xFFFFF);
	float delta_time = (float)(current_ticks - last_ticks) * 0.075f;

	//printf("delta time :  %f \n", delta_time);

	////////////////////////////////////
	//download attractor buffers content
	////////////////////////////////////

	glm::vec4 * attractors = (glm::vec4 *)glMapBufferRange(GL_UNIFORM_BUFFER, //target 
		0, //offset
		32 * sizeof(glm::vec4), //length
		GL_MAP_WRITE_BIT | GL_MAP_INVALIDATE_BUFFER_BIT);//access

	int i;
	//changing the position of the attractors
	for (i = 0; i < 32; i++) {
			attractors[i] = glm::vec4(sinf(time * (float)(i + 4) * 7.5f * 20.0f) * 50.0f,// set x
								      cosf(time * (float)(i + 7) * 3.9f * 20.0f) * 50.0f, // set y
									  sinf(time * (float)(i + 3) * 5.3f * 20.0f) * cosf(time * (float)(i + 5) * 9.1f) * 100.0f, // set z
									  attractor_masses[i]); // get weights from attractor masses array
	}

	glUnmapBuffer(GL_UNIFORM_BUFFER);


	// If dt is too large, the system could explode, so cap it to
	// some maximum allowed value
	if (delta_time >= 2.0f) {
		delta_time = 2.0f;
	}

	// Activate the compute program and bind the position and velocity buffers
	glUseProgram(compute_prog);
	glBindImageTexture(0, // location id 
					   velocity_tbo, // buffer id
					   0, // level
					   GL_FALSE, // layered
					   0, // layer
					   GL_READ_WRITE, //access type 
					   GL_RGBA32F); // image format

	glBindImageTexture(1, position_tbo, 0, GL_FALSE, 0, GL_READ_WRITE, GL_RGBA32F);
	// Set delta time
	glUniform1f(dt_location, delta_time);

	// Dispatch
	glDispatchCompute(PARTICLE_GROUP_COUNT, 1, 1);

	glMemoryBarrier(GL_SHADER_IMAGE_ACCESS_BARRIER_BIT);
	
	glm::mat4 model;
	model = glm::translate(model, glm::vec3(0.0f, 0.0f, -60.0f));
	model = glm::rotate(model,glm::radians( time * 1000.0f), glm::vec3(0.0f, 1.0f, 0.0f));

	glm::mat4 mvp = glm::perspective(45.0f, 1024.0f / 768.0f, 0.1f, 1000.0f) *	model;

	// Clear, select the rendering program and draw a full screen quad
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glDisable(GL_DEPTH_TEST);
		
	
	glUseProgram(render_prog);
	glUniformMatrix4fv(0, 1, GL_FALSE, glm::value_ptr(mvp));
	glBindVertexArray(render_vao);
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE, GL_ONE);
	glPointSize(2.0f);
	glDrawArrays(GL_POINTS, 0, PARTICLE_COUNT);

	last_ticks = current_ticks;

	//int workGroupSize[3];
	//glGetProgramiv(compute_prog, GL_COMPUTE_WORK_GROUP_SIZE, workGroupSize);
	//printf("Local Work group size is %d x %d x %d items.\n", workGroupSize[0], workGroupSize[1], workGroupSize[2]);


	glutSwapBuffers();
}

void update() {


	glutPostRedisplay();
}

int main(int argc, char **argv){

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(140, 140);
	glutInitWindowSize(1024, 768);
	glutCreateWindow("OpenGL First Window");

	glewInit();

	if (glewIsSupported("GL_VERSION_4_5")) {
		std::cout << " GLEW Version is 4.5\n ";
	} else {
		std::cout << "GLEW 4.5 not supported\n ";
	}

	init();

	//glClearColor(1.0, 0.0, 0.0, 1.0);//clear red

	// register callbacks
	glutDisplayFunc(render);
	glutIdleFunc(update);
	glutMainLoop();

	return 0;
}
*/





//**************************************************************
//**************************************************************
// Do NOT uncomment following code.. it is for readability sake
//*************************************************************
//*************************************************************


/*
static const char compute_shader_source[] =

#version 430 core

layout(std140, binding = 0) uniform attractor_block{
	vec4 attractor[64]; // xyz = position, w = mass
};

layout(local_size_x = 128) in;
layout(rgba32f, binding = 0) uniform imageBuffer velocity_buffer;
layout(rgba32f, binding = 1) uniform imageBuffer position_buffer;

uniform float dt = 1.0;

void main(void){

// update position and velocity values from buffer for current global invocation id
vec4 vel = imageLoad(velocity_buffer, int(gl_GlobalInvocationID.x));
vec4 pos = imageLoad(position_buffer, int(gl_GlobalInvocationID.x));

int i;

//update position
pos.xyz += vel.xyz * dt;
pos.w -= 0.0001 * dt;

// update velocity
for (i = 0; i < 4; i++){
	vec3 dist = (attractor[i].xyz - pos.xyz);

	vel.xyz += dt * dt * attractor[i].w * normalize(dist) / (dot(dist, dist) + 10.0);
}

if (pos.w <= 0.0){
pos.xyz = -pos.xyz * 0.01;// set velocity to 0
vel.xyz *= 0.01;// set velocity to close to 0
pos.w += 1.0f; //set life to 1.0 again
}

// update position and velocity to buffer for current global invocation id 
imageStore(position_buffer, int(gl_GlobalInvocationID.x), pos);
imageStore(velocity_buffer, int(gl_GlobalInvocationID.x), vel);
}
*/

/*
Creating, Allocating, and Binding a Texture to an Image Unit
===============================================================
GLuint tex;
// Generate a new name for our texture
glGenTextures(1, &tex);
// Bind it to the regular 2D texture target to create it
glBindTexture(GL_TEXTURE_2D, tex);
// Allocate immutable storage for the texture
glTexStorage2D(GL_TEXTURE_2D, 1, GL_RGBA32F, 512, 512);
// Unbind it from the 2D texture target
glBindTexture(GL_TEXTURE_2D, 0);
// Now bind it for read-write to one of the image units
glBindImageTexture(0, tex, 0, GL_FALSE, 0, GL_READ_WRITE, GL_RGBA32F);
*/

/*
Creating and Binding a Buffer Texture to an Image Unit

GLuint tex, buf;
// Generate a name for the buffer object, bind it to the
// GL_TEXTURE_BINDING, and allocate 4K for the buffer
glGenBuffers(1, &buf);
glBindBuffer(GL_TEXTURE_BUFFER, buf);
glBufferData(GL_TEXTURE_BUFFER, 4096, NULL, GL_DYNAMIC_COPY);

// Generate a new name for our texture
glGenTextures(1, &tex);
// Bind it to the buffer texture target to create it
glBindTexture(GL_TEXTURE_BUFFER, tex);
// Attach the buffer object to the texture and specify format as
// single channel floating point
glTexBuffer(GL_TEXTURE_BUFFER, GL_R32F, buf);
// Now bind it for read-write to one of the image units
glBindImageTexture(0, tex, 0, GL_FALSE, 0, GL_READ_WRITE, GL_RGBA32F);
*/


/*

void main(void){

// Atomic Operations

// Read the current overdraw counter
uint count = imageLoad(overdraw_count, ivec2(gl_FragCoord.xy));
// Add one
count = count + 1;
// Write it back to the image
imageStore(output_buffer, ivec2(gl_FragCoord.xy), count);
}

void main(void){

// Atomically add one to the contents of memory
imageAtomicAdd(overdraw_count, ivec2(gl_FragCoord.xy), 1);
}
